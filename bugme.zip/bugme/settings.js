const fs = require('fs')
const chalk = require('chalk')

global.owner = ['6288219947210','6288219947210'] // ganti nomor wa lu
global.bugrup = ['6288219947210'] // ganti nomor wa lu
global.packname = 'YT : Neo403' 
global.author = 'stick_JaeXploit'

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.yellowBright(`Update File Terbaru ${__filename}`))
delete require.cache[file]
require(file)
})

// SILAHKAN SETTING SESUAI PERINTAH //